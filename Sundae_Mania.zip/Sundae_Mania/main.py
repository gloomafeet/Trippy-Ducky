import pygame
from pygame import mixer
import math
import random

#Initialisation of screen
pygame.init()
pygame.mixer.init()
pygame.display.set_caption('Sundae Mania')
screen = pygame.display.set_mode((376,812))

#Background
B1= pygame.image.load('bg.png')

#ice cream colors
icecream = pygame.image.load('ice-cream.png')
red = pygame.image.load('red.png')
pink = pygame.image.load('pink.png')
yellow = pygame.image.load('yellow.png')
blue = pygame.image.load('blue.png')


#Stripe colours
rs = pygame.image.load('rs.png')
ps = pygame.image.load('ps.png')
ys = pygame.image.load('ys.png')
bs = pygame.image.load('bs.png')

color = rs

#colour list
choice = ['red', 'pink', 'yellow', 'blue']


#player base coordinates
x = 134
y = 500

#stripe coordinates
x1 = -8
y1 = 200

x_change = 2.5
y1_change = 2.5

n = 0
j = red

score = 0
font = pygame.font.Font('freesansbold.ttf', 30)
def Score(x,y):
        score_render = font.render("Score: "+ str(score), True, (255,255,255))
        screen.blit(score_render, (x,y))

render = random.choice(choice)
def Render(x,y):
        render_render = font.render(str(render), True, (0,0,0))
        screen.blit(render_render, (x,y))

def background(B1):
    screen.blit(B1, (0,0))
def IC(name,x,y):
    screen.blit(name, (x,y))
def stripe(color, x1,y1):
    screen.blit(color, (x1,y1))
def collision(x, y, x1, y1):
    distance = math.sqrt(math.pow((x - x1),2) + (math.pow((y - y1),2)))
    if distance < 52:
        return True
    else:
        return False


running = True

while running:
    screen.fill((0,0,0))
    background(B1)
    IC(icecream, x,y)
    Score(120,20)
    Render(150, 310)

    if n == 1:
        stripe(color,x1,y1)
        y1 += y1_change

    coll = collision(x,y,x1,y1)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                scream = mixer.Sound('wa.wav')
                scream.play()
                y1 = 200
                n = 1
                ak = render
                if ak == 'red':
                    color = rs
                    j = red
                    x1 = 67
                    render = random.choice(choice)
                elif ak == 'pink':
                    color = ps
                    j = pink
                    x1 = 230
                    render = random.choice(choice)
                elif ak == 'yellow':
                    color = ys
                    j = yellow
                    x1 = 136
                    render = random.choice(choice)
                elif ak == 'blue':
                    color = bs
                    j = blue
                    x1 = 185
                    render = random.choice(choice)


    if coll:
        score += 1
        n = 0
        icecream = j


    if x >= 300:
        x = 300
        x_change = -2.5
    if x <= -15:
        x = -15
        x_change = 2.5

    x += x_change

    pygame.display.update()
